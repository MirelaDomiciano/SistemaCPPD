-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.4.17-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Copiando estrutura do banco de dados para estagiocppd
CREATE DATABASE IF NOT EXISTS `estagiocppd` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `estagiocppd`;

-- Copiando estrutura para tabela estagiocppd.adm
CREATE TABLE IF NOT EXISTS `adm` (
  `idAdm` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `SIAPE` int(11) DEFAULT NULL,
  PRIMARY KEY (`idAdm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela estagiocppd.adm: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `adm` DISABLE KEYS */;
/*!40000 ALTER TABLE `adm` ENABLE KEYS */;

-- Copiando estrutura para tabela estagiocppd.classe
CREATE TABLE IF NOT EXISTS `classe` (
  `idclasse` int(11) NOT NULL AUTO_INCREMENT,
  `classe` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idclasse`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela estagiocppd.classe: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `classe` DISABLE KEYS */;
INSERT INTO `classe` (`idclasse`, `classe`) VALUES
	(1, 'D I'),
	(2, 'D II'),
	(3, 'D III');
/*!40000 ALTER TABLE `classe` ENABLE KEYS */;

-- Copiando estrutura para tabela estagiocppd.docentes
CREATE TABLE IF NOT EXISTS `docentes` (
  `iddocentes` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `data_ingresso` date DEFAULT NULL,
  `numeromatricula` varchar(45) DEFAULT NULL,
  `titulacao` enum('Graduado','Especialista','Mestre','Doutor') DEFAULT NULL,
  `situacao` enum('Grupo I','Grupo II','Grupo III','Grupo IV','Grupo V') DEFAULT NULL,
  `tipocarreira` enum('Professor EBTT') DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `classe_idclasse` int(11) NOT NULL,
  `nivel_idnivel` int(11) NOT NULL,
  PRIMARY KEY (`iddocentes`),
  KEY `fk_docentes_classe_idx` (`classe_idclasse`),
  KEY `fk_docentes_nivel1_idx` (`nivel_idnivel`),
  CONSTRAINT `fk_docentes_classe` FOREIGN KEY (`classe_idclasse`) REFERENCES `classe` (`idclasse`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_docentes_nivel1` FOREIGN KEY (`nivel_idnivel`) REFERENCES `nivel` (`idnivel`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela estagiocppd.docentes: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `docentes` DISABLE KEYS */;
INSERT INTO `docentes` (`iddocentes`, `nome`, `data_ingresso`, `numeromatricula`, `titulacao`, `situacao`, `tipocarreira`, `email`, `classe_idclasse`, `nivel_idnivel`) VALUES
	(4, 'Maria Joaquina', '2021-01-03', '1234567', 'Especialista', 'Grupo II', 'Professor EBTT', 'email@.com', 1, 1);
/*!40000 ALTER TABLE `docentes` ENABLE KEYS */;

-- Copiando estrutura para tabela estagiocppd.nivel
CREATE TABLE IF NOT EXISTS `nivel` (
  `idnivel` int(11) NOT NULL AUTO_INCREMENT,
  `nivel` varchar(45) DEFAULT NULL,
  `classe_idclasse` int(11) NOT NULL,
  PRIMARY KEY (`idnivel`),
  KEY `fk_nivel_classe1_idx` (`classe_idclasse`),
  CONSTRAINT `fk_nivel_classe1` FOREIGN KEY (`classe_idclasse`) REFERENCES `classe` (`idclasse`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela estagiocppd.nivel: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `nivel` DISABLE KEYS */;
INSERT INTO `nivel` (`idnivel`, `nivel`, `classe_idclasse`) VALUES
	(1, '1', 1);
/*!40000 ALTER TABLE `nivel` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
